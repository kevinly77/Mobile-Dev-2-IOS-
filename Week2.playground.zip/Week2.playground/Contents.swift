//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
// Ex 1
func oldMcDonald(_ animal:String, _ sound:String)->String{
    let txt =   "Old McDonald had a farm. Eyi Eyi oh.\n" +
                "And on his farm he had a \(animal). Eyi Eyi oh.\n" +
                "With a \(sound) \(sound) here, and a \(sound) \(sound) there.\n" +
                "Here \(sound), there \(sound), everywhere a \(sound) \(sound).\n" +
                "Old McDonald had a farm. Eyi Eyi oh.\n"
    return txt
}

print(oldMcDonald("lamb","baa"))
print(oldMcDonald("dog","woof"))
print(oldMcDonald("cat","meow"))
// End Ex1

//Ex2
func xor(_ a:Bool, _ b:Bool) -> Bool{
    return a != b
}
print("xor(True,True)   = ",xor(true,true))
print("xor(True,False)  = ",xor(true,false))
print("xor(False,True)  = ",xor(false,true))
print("xor(False,False) = ",xor(false,false))

func implication(_ a:Bool, _ b:Bool) -> Bool{
    //(true, false) -> false
    //(false, true) -> true
    //(false, false)-> true
    //(true, true) -> true
    
    return !a || b
}
print("implication(True,False)   = ",implication(true,false))
print("implication(False,True)   = ",implication(false,true))
print("implication(False,False)   = ",implication(false,false))
print("implication(True,True)   = ",implication(true,true))
//End Ex2

//Ex3
func factorial(_ n:Int) -> Int{
    let a = n
    if(a == 1){
        return 1
    }else{
        return a*factorial(a-1)
    }
}

factorial(4)

func isPrime(_ n:Int) -> Bool{
    let t = factorial(n-1)+1
    
    return (t % n) == 0
}

isPrime(12)
isPrime(13)
//End Ex3
