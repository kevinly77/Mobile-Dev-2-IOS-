//
//  ViewController.swift
//  Prime
//
//  Created by Tech on 2019-01-14.
//  Copyright © 2019 Tech. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtInput: UITextView!
    
    @IBOutlet weak var txtOutput: UILabel!
    
    @IBAction func check(_ sender: UIButton) {
        let n = Int(txtInput.text!)
        let isP = isPrime(n: n!)
        if(isP){
            txtOutput.text = "\(n!) is a prime number"
        }else{
            txtOutput.text = "\(n!) is not a prime number"
        }
    }
    
    func factorial(n:Int)->Int{
        var f = 1
        for i in 1...n{
            f*=i
        }
        return f
    }
    
    func isPrime(n:Int)->Bool{
        let t = factorial(n: n-1)+1
        return(t%n) == 0
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

